### Step 4: Update the Main App Component

Now, let’s integrate all these components into your main application.

**Edit `src/App.js`:**