import React from 'react';

const Footer = () => {
    return (
        <footer>
            <p>&copy; 2023 Victonnel VPN 254. All rights reserved.</p>
            <p>Created by Victonnel 254</p> {/* Added attribution message */}
        </footer>
    );
};

export default Footer;