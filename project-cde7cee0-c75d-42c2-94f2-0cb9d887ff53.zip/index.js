### Step 7: Run Your Application

Now, you can run your application by executing: