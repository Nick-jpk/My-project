### Step 5: Add Basic Styles

To make your site look nicer, you can add some basic styles. Create a file called `App.css` in the `src` directory and add the following styles: